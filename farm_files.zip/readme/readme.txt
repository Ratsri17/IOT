upload all php files
create database and it's user
edit config.php file accordingly
upload farm.sql file ( it contains many sample data )